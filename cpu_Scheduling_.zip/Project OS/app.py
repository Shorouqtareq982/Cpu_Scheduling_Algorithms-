from flask import Flask, render_template, request
import plotly.graph_objects as go

app = Flask(__name__)

def fcfs_scheduling(processes):
     # Sort processes by arrival tim
    processes.sort(key=lambda x: x['arrival_time'])
    
     # Initialize variables
    start_time = 0
    results = []

    # Process each job
    for process in processes:
        # If the process arrives after the previous process has finished, start at its arrival time
        actual_start_time = max(start_time, process['arrival_time'])

       # Calculate completion time
        completion_time = actual_start_time + process['burst_time']

         # Calculate Turnaround Time
        turnaround_time = completion_time - process['arrival_time']

        # Calculate Waiting Time
        waiting_time = turnaround_time - process['burst_time']

        # Calculate Response Time
        response_time = actual_start_time - process['arrival_time']

        # Update the start time
        start_time = completion_time

        # Store the results
        results.append({
            'id': process['id'],
            'arrival_time': process['arrival_time'],
            'burst_time': process['burst_time'],
            'start_time': actual_start_time,
            'completion_time': completion_time,
            'turnaround_time': turnaround_time, 
            'waiting_time': waiting_time,
            'response_time': response_time
        })

    # Calculate averages
    avg_waiting_time = sum([res['waiting_time'] for res in results]) / len(results)
    avg_turnaround_time = sum([res['turnaround_time'] for res in results]) / len(results)
    avg_response_time = sum([res['response_time'] for res in results]) / len(results)

    # Return results with averages
    return results, avg_waiting_time, avg_turnaround_time, avg_response_time

# SJF Non-Preemptive Scheduling Algorithm
def sjf_non_p_scheduling(processes):
    # Sort processes by arrival time and burst time
    processes.sort(key=lambda x: (x['arrival_time'], x['burst_time']))
    
    current_time = 0
    completed = 0
    results = []
    process_queue = []

    while completed < len(processes):
        # Add ready processes to the queue
        for process in processes:
            if process['arrival_time'] <= current_time and process not in process_queue and process['id'] not in [res['id'] for res in results]:
                process_queue.append(process)

        if process_queue:
            # Choose the process with the shortest burst time
            process_queue.sort(key=lambda x: x['burst_time'])
            current_process = process_queue.pop(0)

            # Calculate start time
            start_time = max(current_time, current_process['arrival_time'])
            
           # Calculate completion time
            completion_time = start_time + current_process['burst_time']
            
            # Calculate Turnaround Time
            turnaround_time = completion_time - current_process['arrival_time']
            
            # Calculate Waiting Time
            waiting_time = turnaround_time - current_process['burst_time']
            
            # Calculate Response Time
            response_time = start_time - current_process['arrival_time']

            # Add results
            results.append({
                'id': current_process['id'],
                'arrival_time': current_process['arrival_time'],
                'burst_time': current_process['burst_time'],
                'start_time': start_time, 
                'completion_time': completion_time,
                'turnaround_time': turnaround_time, 
                'waiting_time': waiting_time,
                'response_time': response_time
            })

            current_time = completion_time  # Update current time
            completed += 1
        else:
            current_time += 1  # Skip time when no ready processes

    # Calculate averages
    avg_waiting_time = sum([res['waiting_time'] for res in results]) / len(results)
    avg_turnaround_time = sum([res['turnaround_time'] for res in results]) / len(results)
    avg_response_time = sum([res['response_time'] for res in results]) / len(results)

     # Return results with averages
    return results, avg_waiting_time, avg_turnaround_time, avg_response_time


# SJF Preemptive Scheduling Algorithm
import heapq  # To use the priority queue

def sjf_p_scheduling(processes):
    # Sort processes by arrival time
    processes.sort(key=lambda x: x['arrival_time'])  
    n = len(processes)
    remaining_burst_time = [p['burst_time'] for p in processes]
    response_time = [-1] * n
    start_time = [-1] * n  # Store the start time of each process
    completed = 0
    current_time = 0
    results = []
    ready_queue = []  # Ready queue for processes

    while completed < n:
        # Add ready processes to the queue
        for i in range(n):
            if processes[i]['arrival_time'] <= current_time and remaining_burst_time[i] > 0 and i not in [item[1] for item in ready_queue]:
                # Add process to the queue based on remaining burst time
                heapq.heappush(ready_queue, (remaining_burst_time[i], i))  

        if ready_queue:
            # Extract the process with the shortest remaining burst time from the queue
            _, idx = heapq.heappop(ready_queue)

            # Calculate response time if it's the first time this process is executed
            if response_time[idx] == -1:
                response_time[idx] = current_time - processes[idx]['arrival_time']
                start_time[idx] = current_time   # Record the start time

            # Execute part of the process
            remaining_burst_time[idx] -= 1
            current_time += 1

            # If the process is completed, calculate its times
            if remaining_burst_time[idx] == 0:
                completed += 1
                completion_time = current_time
                turnaround_time = completion_time - processes[idx]['arrival_time']
                waiting_time = turnaround_time - processes[idx]['burst_time']

                results.append({
                    'id': processes[idx]['id'],
                    'arrival_time': processes[idx]['arrival_time'],
                    'burst_time': processes[idx]['burst_time'],
                    'start_time': start_time[idx],
                    'completion_time': completion_time,
                    'turnaround_time': turnaround_time,
                    'waiting_time': waiting_time,
                    'response_time': response_time[idx]
                })
        else:
            # If no processes are ready, advance the time
            current_time += 1

    # Calculate averages
    avg_waiting_time = sum(res['waiting_time'] for res in results) / n
    avg_turnaround_time = sum(res['turnaround_time'] for res in results) / n
    avg_response_time = sum(res['response_time'] for res in results) / n

    return results, avg_waiting_time, avg_turnaround_time, avg_response_time

# Round Robin Scheduling Algorithm
def round_robin(processes, time_quantum):
    n = len(processes)
    remaining_times = {p['id']: p['burst_time'] for p in processes}
    waiting_times = {p['id']: 0 for p in processes}
    start_times = {p['id']: None for p in processes}  
    completion_times = {}
    response_times = {}
    current_time = 0
    # Ready processes list
    queue = [process for process in processes if process['arrival_time'] <= current_time]
    # Sort processes by arrival time 
    processes = sorted(processes, key=lambda p: p['arrival_time'])

    while queue or any(remaining_times.values()):
        if not queue:
            # If no processes are ready, move time forward
            current_time += 1  
            queue = [process for process in processes if process['arrival_time'] <= current_time and remaining_times[process['id']] > 0]
            continue

        process = queue.pop(0)
        pid = process['id']

         # Record the start time the first time the process is executed
        if start_times[pid] is None:
            start_times[pid] = current_time
            response_times[pid] = current_time - process['arrival_time']

        executed_time = min(time_quantum, remaining_times[pid])
        current_time += executed_time
        remaining_times[pid] -= executed_time

        # Update the ready queue
        for p in processes:
            if p['arrival_time'] <= current_time and remaining_times[p['id']] > 0 and p not in queue:
                queue.append(p)

         # Re-add the process to the queue if it has not finished
        if remaining_times[pid] > 0:
            queue.append(process)
        else:
            completion_times[pid] = current_time  

    # Calculate the final results
    results = []
    for process in processes:
        pid = process['id']
        completion_time = completion_times[pid]
        start_time = start_times[pid]
        turnaround_time = completion_time - process['arrival_time']
        waiting_time = turnaround_time - process['burst_time']
        response_time = start_time - process['arrival_time']
        results.append({
            'id': pid,
            'arrival_time': process['arrival_time'],
            'burst_time': process['burst_time'],
            'start_time': start_time,
            'completion_time': completion_time,
            'turnaround_time': turnaround_time,
            'waiting_time': waiting_time,
            'response_time': response_time
        })

    avg_waiting_time = sum([res['waiting_time'] for res in results]) / n
    avg_turnaround_time = sum([res['turnaround_time'] for res in results]) / n
    avg_response_time = sum([res['response_time'] for res in results]) / n

    return results, avg_waiting_time, avg_turnaround_time, avg_response_time

# Priority Scheduling Algorithm
def priority_scheduling(processes):
   # Sort processes by priority, and by arrival time if priorities are the same
    processes.sort(key=lambda x: (x['priority'], x['arrival_time']))
    
    current_time = 0
    results = []

    for process in processes:
        # If the process arrives after the previous one finishes, update the current time
        start_time = max(current_time, process['arrival_time'])
        completion_time = start_time + process['burst_time']
        turnaround_time = completion_time - process['arrival_time']
        waiting_time = turnaround_time - process['burst_time']
        response_time = start_time - process['arrival_time']

       # Update the current time
        current_time = completion_time

        # Add the results
        results.append({
            'id': process['id'],
            'arrival_time': process['arrival_time'],
            'burst_time': process['burst_time'],
            'priority': process['priority'],
            'start_time': start_time,
            'completion_time': completion_time,
            'turnaround_time': turnaround_time,
            'waiting_time': waiting_time,
            'response_time': response_time
        })

    # Calculate averages
    n = len(processes)
    avg_waiting_time = sum([res['waiting_time'] for res in results]) / n
    avg_turnaround_time = sum([res['turnaround_time'] for res in results]) / n
    avg_response_time = sum([res['response_time'] for res in results]) / n

    return results, avg_waiting_time, avg_turnaround_time, avg_response_time



# Home page
@app.route('/')
def home():
    return render_template('home.html')

# Different scheduling pages
@app.route("/fcfs")
def fcfs_page():
    return render_template("First Come First Served (FCFS)-about.html")

@app.route("/sjf-non-preemptive")
def sjf_non_preemptive_page():
    return render_template("Non-Preemptive Shortest Job First (SJF)-about.html")

@app.route("/sjf-preemptive")
def sjf_preemptive_page():
    return render_template("Preemptive Shortest Job First (SJF)-about.html")

@app.route("/round-robin")
def round_robin_page():
    return render_template("Round Robin (RR)-about.html")

@app.route("/priority")
def priority_page():
    return render_template("Priority Scheduling-about.html")

# Gantt Chart Generator
def create_gantt_chart(results):
    fig = go.Figure()

    for process in results:
        fig.add_trace(go.Bar(
            x=[process['burst_time']],
            y=[f"Process {process['id']}"],
            base=process['completion_time'] - process['burst_time'],
            orientation='h',
            name=f"Process {process['id']}"
        ))

    fig.update_layout(
        title="Gantt Chart",
        xaxis_title="Time",
        yaxis_title="Processes",
        barmode='stack',
        xaxis=dict(showgrid=True),
        yaxis=dict(showgrid=True)
    )
    return fig.to_html(full_html=False)

@app.route('/index', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        n = int(request.form['num_processes'])
        processes = []

        for i in range(n):
            processes.append({
                'id': request.form[f'process_id_{i+1}'],
                'arrival_time': int(request.form[f'arrival_time_{i+1}']),
                'burst_time': int(request.form[f'burst_time_{i+1}']),
                'priority': int(request.form.get(f'priority_input_{i+1}', '0') or '0')
            })

        scheduling_type = request.form['scheduling_type']
        results, avg_waiting_time, avg_turnaround_time, avg_response_time = [], 0, 0, 0

        if scheduling_type == 'FCFS':
            results, avg_waiting_time, avg_turnaround_time, avg_response_time = fcfs_scheduling(processes)
        elif scheduling_type == 'SJF_non_P':
            results, avg_waiting_time, avg_turnaround_time, avg_response_time = sjf_non_p_scheduling(processes)
        elif scheduling_type == 'SJF_P':
            results, avg_waiting_time, avg_turnaround_time, avg_response_time = sjf_p_scheduling(processes)
        elif scheduling_type == 'Round Robin':
            time_quantum = int(request.form['time_quantum'])
            results, avg_waiting_time, avg_turnaround_time, avg_response_time = round_robin(processes, time_quantum)
        elif scheduling_type == 'Priority':
            results, avg_waiting_time, avg_turnaround_time, avg_response_time = priority_scheduling(processes)

        # Create bar chart for waiting and turnaround times
        fig = go.Figure()
        fig.add_trace(go.Bar(x=[res['id'] for res in results], y=[res.get('waiting_time', 0) for res in results], name='Waiting Time'))
        fig.add_trace(go.Bar(x=[res['id'] for res in results], y=[res.get('turnaround_time', 0) for res in results], name='Turnaround Time'))
        fig.add_trace(go.Bar(x=[res['id'] for res in results], y=[res.get('response_time', 0) for res in results], name='Response Time'))
        graph_html = fig.to_html(full_html=False)

        # Create Gantt Chart
        gantt_chart_html = create_gantt_chart(results)

        return render_template(
            'result.html',
            graph_html=graph_html,
            gantt_chart_html=gantt_chart_html,
            results=results,
            avg_waiting_time=avg_waiting_time,
            avg_turnaround_time=avg_turnaround_time,
            avg_response_time=avg_response_time
        )

    return render_template('index.html')

if __name__ == "__main__":
    app.run(debug=True)
